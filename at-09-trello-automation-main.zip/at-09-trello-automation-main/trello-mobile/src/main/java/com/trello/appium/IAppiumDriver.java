package com.trello.appium;

import io.appium.java_client.AppiumDriver;

public interface IAppiumDriver {
    AppiumDriver initDriver();
}
