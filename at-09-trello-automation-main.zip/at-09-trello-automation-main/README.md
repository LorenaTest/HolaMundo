# at-09-trello-automation

---

Command to run api tests
```
gradle clean apiFeatures -Ptags="@Board"
```