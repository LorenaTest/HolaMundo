package com.trello.appium;

public enum Mobile {
    Android,
    Android_BrowserStack,
    Android_BrowserStackIOS
}
